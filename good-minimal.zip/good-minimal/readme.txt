Theme Name: Good Minimal
Theme URI: http://themeforest.net/user/wpstall/portfolio
Description: Good Minimal is a clean and minimalist style theme that is good for portfolio, blogs and businesses. This theme is flexible and is used media queries to adapt screen sizes, weither it is iphone, ipad and wide screens.
Author: WPSTALL
Author URI: http://themeforest.net/user/wpstall